<?php echo e($slot); ?>

<?php /**PATH C:\Users\j-vic\Desktop\Curso desenvolvimento de Sistemas\FATEC\5º Modulo\Eletiva - Programação WEB II\Aula 02-04-2022\ecommerce\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>