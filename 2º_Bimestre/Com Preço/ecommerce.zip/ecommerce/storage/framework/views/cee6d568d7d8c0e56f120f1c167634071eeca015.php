<table class="subcopy" width="100%" cellpadding="0" cellspacing="0" role="presentation">
<tr>
<td>
<?php echo e(Illuminate\Mail\Markdown::parse($slot)); ?>

</td>
</tr>
</table>
<?php /**PATH C:\Users\j-vic\Desktop\Curso desenvolvimento de Sistemas\FATEC\5º Modulo\Eletiva - Programação WEB II\Aula 02-04-2022\ecommerce\vendor\laravel\framework\src\Illuminate\Mail/resources/views/html/subcopy.blade.php ENDPATH**/ ?>